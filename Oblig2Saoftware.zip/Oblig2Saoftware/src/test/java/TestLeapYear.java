import no.mostafam.software.Year;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

public class TestLeapYear {

        // må lage tester for hvert eneste krav fra akseptansekrav
        //viktig å lage enkelte tester for hvert eneste.
        Year verifing = new Year();

            //arrange
            final int input = 1000;
            final String excepcted = "I";

        @Test
        public void test_Divides_By_Four_not_hundred_Int_LeapYear() {



            //sjekker om det stemmer om det er skuddår
            assertEquals(true, verifing.isLeapYear(4));
            assertEquals(true, verifing.isLeapYear(8));

        }

        @Test
        public void test_Divides_By_FourHoundred_Int_LeapYear() {

            //sjekker om det stemmer om det er skuddår

            assertEquals(true, verifing.isLeapYear(400));
            assertEquals(true, verifing.isLeapYear(800));


        }

        @Test
        public void test_Not_Divisible_by_four(){
            assertEquals(false, verifing.isLeapYear(300));
            assertEquals(false, verifing.isLeapYear(600));
            assertEquals(false, verifing.isLeapYear(900));

        }

        @Test
        public void test_Divisible_By_hundred_Not_Divisible_by_FourHundred(){
            assertEquals(false, verifing.isLeapYear(100));
            assertEquals(false, verifing.isLeapYear(1500));




        }


    }


